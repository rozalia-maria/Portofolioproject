<!DOCTYPE html>
<html>

<head>
  <title>Portfolio of The Website Designer</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta charset="utf-8">
<link rel="stylesheet"
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-uWxY/CJNBR+1zjPWmfnSnVxwRheevXITnMqoEIeG1LJrdI0GlVs/9cVSyPYXdcSF" crossorigin="anonymous">
<link rel="stylesheet" href="style.css">
<head>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.10.2/dist/umd/popper.min.js" integrity="sha384-7+zCNj/IqJ95wo16oMtfsKbZ9ccEh31eOz1HGyDuCQ6wgnyJNSYdrPa03rtR1zdB" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.2/dist/js/bootstrap.min.js" integrity="sha384-PsUw7Xwds7x08Ew3exXhqzbhuEYmA2xnwc8BuD6SEr+UmEHlX8/MCltYEodzWA4u" crossorigin="anonymous"></script>
</head>
<body>
<ul>
<li><a href="index.html">Home</a></li>
<li><a href="about.html ">About</a></li>
<li><a href="projects.html">Projects</a></li>
<li><a href="contact.html">Contact</a></li>
</ul>
<h1 class="title">Portfolio of The Web Designer</h1>
<p>Welcome to the portfolio of The Website Designer</p>
<h2>About The Web Designer</h2>
<p>I am a freelance web designer, recently qualified from Dumfries and Galloway College. I enjoy creating well designed,
intuitive and functional websites.</p>
<h3>Services Offered</h3>
<p>I am happy to offer a range of services suitable for your requirements. These include:</p>
<ul>
<li>HTML websites </li>
<li>CSS knowledge</li>
<li>Image optimisation</li>
<li>Logo and banner design</li>
</ul>
<img src="https://iili.io/27EDmJ.md.jpg" alt="27EDmJ.md.jpg" border="0" width="500px">
<img src="https://iili.io/27Eysp.md.jpg" alt="27EDmJ.md.jpg" border="0" width="500px">
</body>
</html>